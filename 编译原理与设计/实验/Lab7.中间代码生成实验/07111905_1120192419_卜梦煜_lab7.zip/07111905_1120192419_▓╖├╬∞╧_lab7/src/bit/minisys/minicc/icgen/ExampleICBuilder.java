package bit.minisys.minicc.icgen;

import bit.minisys.minicc.parser.ast.*;
import bit.minisys.minicc.semantic.SymbolTable;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

// һ����������ֻʵ���˼ӷ�
public class ExampleICBuilder implements ASTVisitor {

    private Map<ASTNode, ASTNode> map;                // ʹ��map�洢�ӽڵ�ķ���ֵ��key��Ӧ�ӽڵ㣬value��Ӧ����ֵ��valueĿǰ������ASTIdentifier,ASTIntegerConstant,TemportaryValue...
    private List<Quat> quats;                        // ���ɵ���Ԫʽ�б�
    private Integer tmpId;                            // ��ʱ�������

    // ���ű�
    public SymbolTable globalSymbolTable;
    public SymbolTable localSymbolTable;
    public SymbolTable functionTable;

    Map<String, ASTNode> labelTable;

    // ѭ������
    public Integer iterationId;
    public Integer jmpLabelId;

    public ExampleICBuilder() {
        this.map = new HashMap<ASTNode, ASTNode>();
        this.quats = new LinkedList<Quat>();
        this.tmpId = 0;
        this.iterationId = 0;
        this.jmpLabelId = 0;

        this.globalSymbolTable = new SymbolTable();
        this.localSymbolTable = new SymbolTable();
        this.functionTable = new SymbolTable();

        this.labelTable = new HashMap<String, ASTNode>();
    }

    public List<Quat> getQuats() {
        return quats;
    }

    // functionList -> functionDefine functionList | e
    @Override
    public void visit(ASTCompilationUnit program) throws Exception {
        for (ASTNode node : program.items) {
            if (node instanceof ASTFunctionDefine) {
                this.visit((ASTFunctionDefine) node);
            } else if (node instanceof ASTDeclaration) {
                this.visit((ASTDeclaration) node);
            }
        }
    }

    // declaration -> typeSpecifiers initDeclaratorList ';'
    // initDeclaratorList -> initDeclarator | initDeclarator ',' initDeclaratorList
    // initDeclarator -> declarator | declarator '=' initializer
    // declarator -> identifier postDeclarator
    // postDeclarator -> '[' assignmentExpression ']' postDeclarator | '[' ']' postDeclarator | e
    // initializer -> assignmentExpression | '{' expression '}'
    @Override
    public void visit(ASTDeclaration declaration) throws Exception {
        declaration.scope = this.localSymbolTable;

        String typeSpecifiers = declaration.specifiers.get(0).value;

        for (ASTInitList initDeclarator : declaration.initLists) {
            this.visit(initDeclarator);

            String name = initDeclarator.declarator.getName();
            ASTDeclarator declarator = initDeclarator.declarator;

            if (declarator instanceof ASTVariableDeclarator) {
                if (declaration.scope == this.globalSymbolTable) {
                    this.globalSymbolTable.addVariable(name, typeSpecifiers);
                } else if (declaration.scope == this.localSymbolTable) {
                    this.localSymbolTable.addVariable(name, typeSpecifiers);
                }
                Quat quat = new Quat("var", declarator, declaration.specifiers.get(0), null);
                quats.add(quat);

                // �г�ֵ�����ټ�һ������ֵ����Ԫʽ
                if (!initDeclarator.exprs.isEmpty()) {
                    String op = "=";
                    ASTNode opnd1 = null;
                    ASTNode opnd2 = null;

                    ASTExpression expr = initDeclarator.exprs.get(0);

                    // ����������������ֵ
                    if (expr instanceof ASTIdentifier || expr instanceof ASTIntegerConstant ||
                            expr instanceof ASTFloatConstant || expr instanceof ASTCharConstant ||
                            expr instanceof ASTStringConstant) {
                        opnd1 = expr;
                    }
                    // ˫Ŀ����
                    else if (expr instanceof ASTBinaryExpression) {
                        ASTBinaryExpression be = (ASTBinaryExpression) expr;
                        op = be.op.value;
                        this.visit(be.expr1);
                        this.visit(be.expr2);
                        opnd1 = map.get(be.expr1);
                        opnd2 = map.get(be.expr2);
                    }
                    // ��Ŀ����
                    else if (expr instanceof ASTPostfixExpression || expr instanceof ASTUnaryExpression ||
                            expr instanceof ASTFunctionCall) {
                        this.visit(expr);
                        opnd1 = map.get(expr);
                    }
                    Quat quat1 = new Quat(op, declarator, opnd1, opnd2);
                    quats.add(quat1);
                    map.put(initDeclarator, declarator);
                }
            } else if (declarator instanceof ASTArrayDeclarator) {
                ASTDeclarator arrayDeclarator = ((ASTArrayDeclarator) declarator).declarator;
                ASTExpression expr = ((ASTArrayDeclarator) declarator).expr;

                LinkedList<Integer> arrayLimit = new LinkedList<Integer>();

                // ȡ�������ά��С����������������У��±�������ʵ�� int[10][20]
                while (true) {
                    int limit = ((ASTIntegerConstant) expr).value;
                    arrayLimit.addFirst(limit);

                    if (arrayDeclarator instanceof ASTArrayDeclarator) {
                        expr = ((ASTArrayDeclarator) arrayDeclarator).expr;
                        arrayDeclarator = ((ASTArrayDeclarator) arrayDeclarator).declarator;
                    } else {
                        break;
                    }
                }

                // ���ɸ��������������
                for (int limit : arrayLimit) {
                    typeSpecifiers += "[" + limit + "]";
                }
                DescriptionLabel compoundTypeLabel = new DescriptionLabel(typeSpecifiers);

                if (declaration.scope == this.globalSymbolTable) {
                    this.globalSymbolTable.addVariable(name, typeSpecifiers, arrayLimit);
                } else {
                    this.localSymbolTable.addVariable(name, typeSpecifiers, arrayLimit);
                }

                Quat quat = new Quat("arr", arrayDeclarator, compoundTypeLabel, null);
                quats.add(quat);
            }
        }
    }

    @Override
    public void visit(ASTArrayDeclarator arrayDeclarator) throws Exception {
        // TODO Auto-generated method stub
        this.visit(arrayDeclarator.declarator);
        this.visit(arrayDeclarator.expr);
    }

    @Override
    public void visit(ASTVariableDeclarator variableDeclarator) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void visit(ASTFunctionDeclarator functionDeclarator) throws Exception {
        // TODO Auto-generated method stub
        this.visit(functionDeclarator.declarator);
    }

    @Override
    public void visit(ASTParamsDeclarator paramsDeclarator) throws Exception {
        // TODO Auto-generated method stub

    }

    // a[idx(1)]...[idx(n)]Ҫ�ȼ������λ����ȡֵ
    // ("*", idx(n-1), size(n), temp1), ("+", temp1, idx(n), temp1)
    @Override
    public void visit(ASTArrayAccess arrayAccess) throws Exception {
        // TODO Auto-generated method stub
        ASTExpression compoundArrayName = arrayAccess.arrayName;
        ASTExpression currentIndex = arrayAccess.elements.get(0);

        // ���������±�
        LinkedList<ASTNode> index = new LinkedList<>();

        while (compoundArrayName instanceof ASTArrayAccess) {
            this.visit(currentIndex);
            ASTNode rest = map.get(currentIndex);
            index.addFirst(rest);
            currentIndex = ((ASTArrayAccess) compoundArrayName).elements.get(0);
            compoundArrayName = ((ASTArrayAccess) compoundArrayName).arrayName;
        }
        String arrayName = ((ASTIdentifier) compoundArrayName).value;

        // ����ʵ�ʴ�С
        LinkedList<Integer> size = null;
        if (this.localSymbolTable.findAll(arrayName)) {
            size = this.localSymbolTable.getArrayLimit(arrayName);
        } else {
            size = this.globalSymbolTable.getArrayLimit(arrayName);
        }

        // ��¼����ά�������С
        int num = 1;
        LinkedList<Integer> record = new LinkedList<>();
        for (int i = size.size() - 1; i > 0; i--) {
            num *= size.get(i);
            record.addFirst(num);
        }

        ASTNode t1 = new TemporaryValue(++tmpId);
        ASTNode t2 = new TemporaryValue(++tmpId);

        if (this.globalSymbolTable == this.localSymbolTable) {
            this.globalSymbolTable.addVariable(((TemporaryValue) t1).name(), "int");
            this.globalSymbolTable.addVariable(((TemporaryValue) t2).name(), "int");
        } else {
            this.localSymbolTable.addVariable(((TemporaryValue) t1).name(), "int");
            this.localSymbolTable.addVariable(((TemporaryValue) t2).name(), "int");
        }

        // ��������Ƕ�׼����С����Ԫʽ
        Quat quat = new Quat("=", t2, t1, null);
        quats.add(quat);

        for (int i = 0; i < size.size() - 1; i++) {
            ASTIntegerConstant temp = new ASTIntegerConstant((Integer) record.get(i), -1);
            Quat quat1 = new Quat("*", t1, (ASTNode) index.get(i), temp);
            quats.add(quat1);
            Quat quat2 = new Quat("+", t2, t1, t2);
            quats.add(quat2);
        }

        Quat quat3 = new Quat("+", t2, t2, (ASTNode) index.get(index.size() - 1));
        quats.add(quat3);

        ASTNode t3 = new TemporaryValue(++tmpId);
        if (this.globalSymbolTable == this.localSymbolTable) {
            this.globalSymbolTable.addVariable(((TemporaryValue) t3).name(), "int");
        } else {
            this.localSymbolTable.addVariable(((TemporaryValue) t3).name(), "int");
        }

        Quat quat4 = new Quat("=[]", t3, t2, compoundArrayName);
        quats.add(quat4);
        map.put(arrayAccess, t3);

    }

    @Override
    public void visit(ASTBinaryExpression binaryExpression) throws Exception {
        String op = binaryExpression.op.value;
        ASTNode res = null;
        ASTNode opnd1 = null;
        ASTNode opnd2 = null;

        if (op.equals("=")) {
            // ��ֵ����
            // ��ȡ����ֵ�Ķ���res
            visit(binaryExpression.expr1);
            res = map.get(binaryExpression.expr1);
            // �ж�Դ����������, Ϊ�˱������a = b + c; ����������Ԫʽ��tmp1 = b + c; a = tmp1;�������Ҳ�����ñ�ķ������
            if (binaryExpression.expr2 instanceof ASTIdentifier) {
                opnd1 = binaryExpression.expr2;
            } else if (binaryExpression.expr2 instanceof ASTIntegerConstant) {
                opnd1 = binaryExpression.expr2;
            } else if (binaryExpression.expr2 instanceof ASTCharConstant) {
                opnd1 = binaryExpression.expr2;
            } else if (binaryExpression.expr2 instanceof ASTStringConstant) {
                opnd1 = binaryExpression.expr2;
            } else if (binaryExpression.expr2 instanceof ASTBinaryExpression) {
                ASTBinaryExpression value = (ASTBinaryExpression) binaryExpression.expr2;
                op = value.op.value;
                visit(value.expr1);
                opnd1 = map.get(value.expr1);
                visit(value.expr2);
                opnd2 = map.get(value.expr2);
            } else if (binaryExpression.expr2 instanceof ASTArrayAccess) {
                this.visit(binaryExpression.expr2);
                opnd1 = map.get(binaryExpression.expr2);
            } else if (binaryExpression.expr2 instanceof ASTUnaryExpression) {
                this.visit(binaryExpression.expr2);
                opnd1 = map.get(binaryExpression.expr2);
            } else if (binaryExpression.expr2 instanceof ASTPostfixExpression) {
                this.visit(binaryExpression.expr2);
                opnd1 = map.get(binaryExpression.expr2);
            } else if (binaryExpression.expr2 instanceof ASTFunctionCall) {
                this.visit(binaryExpression.expr2);
                opnd1 = map.get(binaryExpression.expr2);
            }
        } else if (op.equals("+") || op.equals("-") ||
                op.equals("*") || op.equals("/") ||
                op.equals("%") || op.equals(">=") ||
                op.equals("<=") || op.equals(">") ||
                op.equals("<") || op.equals("==") ||
                op.equals("!=") || op.equals("&&") ||
                op.equals("||")) {
            // ˫Ŀ�������������洢���м����
            res = new TemporaryValue(++tmpId);
            visit(binaryExpression.expr1);
            opnd1 = map.get(binaryExpression.expr1);
            visit(binaryExpression.expr2);
            opnd2 = map.get(binaryExpression.expr2);

            String name = ((TemporaryValue) res).name();
            String type = "char";
            if (opnd1 instanceof ASTFloatConstant || opnd2 instanceof ASTFloatConstant) {
                type = "float";
            } else if (opnd1 instanceof ASTIntegerConstant || opnd2 instanceof ASTIntegerConstant) {
                type = "int";
            }

            if (this.globalSymbolTable == this.localSymbolTable) {
                this.globalSymbolTable.addVariable(name, type);
            } else {
                this.localSymbolTable.addVariable(name, type);
            }

        } else if (op.equals("+=") || op.equals("-=") || op.equals("*=") ||
                op.equals("/=") || op.equals("%=")) {
            this.visit(binaryExpression.expr1);
            opnd1 = map.get(binaryExpression.expr1);
            this.visit(binaryExpression.expr2);
            opnd2 = map.get(binaryExpression.expr2);
            res = opnd1;
        }

        // build quat
        Quat quat = new Quat(op, res, opnd1, opnd2);
        quats.add(quat);
        map.put(binaryExpression, res);

    }

    @Override
    public void visit(ASTBreakStatement breakStat) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void visit(ASTContinueStatement continueStatement) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void visit(ASTCastExpression castExpression) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void visit(ASTCharConstant charConst) throws Exception {
        // TODO Auto-generated method stub
        map.put(charConst, charConst);
    }

    @Override
    public void visit(ASTCompoundStatement compoundStat) throws Exception {
        for (ASTNode node : compoundStat.blockItems) {
            if (node instanceof ASTDeclaration) {
                this.visit((ASTDeclaration) node);
            } else if (node instanceof ASTStatement) {
                this.visit((ASTStatement) node);
            }
        }

    }

    @Override
    public void visit(ASTConditionExpression conditionExpression) throws Exception {
        // TODO Auto-generated method stub

    }

    @Override
    public void visit(ASTExpression expression) throws Exception {
        if (expression instanceof ASTArrayAccess) {
            visit((ASTArrayAccess) expression);
        } else if (expression instanceof ASTBinaryExpression) {
            visit((ASTBinaryExpression) expression);
        } else if (expression instanceof ASTCastExpression) {
            visit((ASTCastExpression) expression);
        } else if (expression instanceof ASTCharConstant) {
            visit((ASTCharConstant) expression);
        } else if (expression instanceof ASTConditionExpression) {
            visit((ASTConditionExpression) expression);
        } else if (expression instanceof ASTFloatConstant) {
            visit((ASTFloatConstant) expression);
        } else if (expression instanceof ASTFunctionCall) {
            visit((ASTFunctionCall) expression);
        } else if (expression instanceof ASTIdentifier) {
            visit((ASTIdentifier) expression);
        } else if (expression instanceof ASTIntegerConstant) {
            visit((ASTIntegerConstant) expression);
        } else if (expression instanceof ASTMemberAccess) {
            visit((ASTMemberAccess) expression);
        } else if (expression instanceof ASTPostfixExpression) {
            visit((ASTPostfixExpression) expression);
        } else if (expression instanceof ASTStringConstant) {
            visit((ASTStringConstant) expression);
        } else if (expression instanceof ASTUnaryExpression) {
            visit((ASTUnaryExpression) expression);
        } else if (expression instanceof ASTUnaryTypename) {
            visit((ASTUnaryTypename) expression);
        }
    }

    @Override
    public void visit(ASTExpressionStatement expressionStat) throws Exception {
        for (ASTExpression node : expressionStat.exprs) {
            visit((ASTExpression) node);
        }
    }

    @Override
    public void visit(ASTFloatConstant floatConst) throws Exception {
        // TODO Auto-generated method stub
        map.put(floatConst, floatConst);
    }

    // ("call", functionName, , ) / ("call", functionname, , temp)
    // ("arg", type, functionName, name)
    @Override
    public void visit(ASTFunctionCall funcCall) throws Exception {
        // TODO Auto-generated method stub
        String functionName = ((ASTIdentifier) funcCall.funcname).value;
        DescriptionLabel functionLabel = new DescriptionLabel(functionName);

        String returnType = this.functionTable.getArrayType(functionName);
        if (returnType == null || returnType.equals("void")) {
            Quat quat = new Quat("call", null, funcCall.funcname, null);
            quats.add(quat);
        } else {
            ASTNode temp = new TemporaryValue(++tmpId);
            String name = ((TemporaryValue) temp).name();
            if (this.globalSymbolTable == this.localSymbolTable) {
                this.globalSymbolTable.addVariable(name, returnType);
            } else {
                this.localSymbolTable.addVariable(name, returnType);
            }
            Quat quat = new Quat("call", temp, funcCall.funcname, null);
            quats.add(quat);
            map.put(funcCall, temp);
        }

        for (ASTExpression expr : funcCall.argList) {
            this.visit(expr);
            ASTNode arg = map.get(expr);

            Quat quat = new Quat("arg", arg, functionLabel, null);
            quats.add(quat);
        }
    }

    @Override
    public void visit(ASTGotoStatement gotoStat) throws Exception {
        // TODO Auto-generated method stub
        String labelName = gotoStat.label.value;
        ASTNode label = this.labelTable.get(labelName);
        Quat quat = new Quat("jmp", label, null, null);
        quats.add(quat);
    }

    @Override
    public void visit(ASTIdentifier identifier) throws Exception {
        map.put(identifier, identifier);
    }

    @Override
    public void visit(ASTInitList initList) throws Exception {
        // TODO Auto-generated method stub
        if (initList.declarator instanceof ASTVariableDeclarator) {
            this.visit((ASTVariableDeclarator) initList.declarator);
            for (ASTExpression expr : initList.exprs) {
                this.visit(expr);
            }
        } else if (initList.declarator instanceof ASTArrayDeclarator) {
            this.visit((ASTArrayDeclarator) initList.declarator);
        } else if (initList.declarator instanceof ASTFunctionDeclarator) {
            this.visit((ASTFunctionDeclarator) initList.declarator);
        }
    }

    @Override
    public void visit(ASTIntegerConstant intConst) throws Exception {
        map.put(intConst, intConst);
    }

    // ("iterationBegin", , , scopeName) ("iterationEnd", , , scopeName)
    // ˳��init -> (CheckCondLabel) -> cond -> (jmpCondFalse) -> state -> step -> (jmpCheckCond) -> (CondFalseLabel)
    @Override
    public void visit(ASTIterationDeclaredStatement iterationDeclaredStat) throws Exception {
        // TODO Auto-generated method stub
        if (iterationDeclaredStat == null) {
            return;
        }

        iterationDeclaredStat.scope = this.localSymbolTable;
        this.localSymbolTable = new SymbolTable();
        this.localSymbolTable.father = iterationDeclaredStat.scope;

        String scopeBeginName = "iterationScope" + this.iterationId++;
        DescriptionLabel iterationScope = new DescriptionLabel(scopeBeginName);
        Quat quat = new Quat("iterationBegin", iterationScope, null, null);
        quats.add(quat);

        if (iterationDeclaredStat.init != null) {
            this.visit(iterationDeclaredStat.init);
        }

        String condInL = "iterationCondInLabel" + this.jmpLabelId++;
        DescriptionLabel condInLabel = new DescriptionLabel(condInL, this.quats.size());
        Quat quat1 = new Quat("label", condInLabel, null, null);
        quats.add(quat1);

        if (iterationDeclaredStat.cond != null) {
            for (ASTExpression cond : iterationDeclaredStat.cond)
                this.visit(cond);
        }

        String gotoIterationEnd = "iterationGotoEnd" + this.jmpLabelId++;
        DescriptionLabel gotoIterationEndLabel = new DescriptionLabel(gotoIterationEnd);

        Quat quat2 = new Quat("jf", gotoIterationEndLabel, null, null);
        quats.add(quat2);

        this.visit(iterationDeclaredStat.stat);

        String gotocondCheck = "iterationGotoCond" + this.jmpLabelId++;
        DescriptionLabel gotocondCheckLabel = new DescriptionLabel(gotocondCheck, this.quats.size());

        Quat quat3 = new Quat("label", gotocondCheckLabel, null, null);
        quats.add(quat3);

        if (iterationDeclaredStat.step != null) {
            for (ASTExpression step : iterationDeclaredStat.step)
                this.visit(step);
        }

        Quat quat4 = new Quat("jmp", condInLabel, null, null);
        quats.add(quat4);

        Quat quat5 = new Quat("label", gotoIterationEndLabel, null, null);
        quats.add(quat5);

        String scopeEndName = "iterationScopeBegin" + this.iterationId++;
        Quat quat6 = new Quat("iterationEnd", iterationScope, null, null);
        quats.add(quat6);

        // ���ű��л�
        this.localSymbolTable = iterationDeclaredStat.scope;

    }

    @Override
    public void visit(ASTIterationStatement iterationStat) throws Exception {
        // TODO Auto-generated method stub
        if (iterationStat == null) {
            return;
        }

        iterationStat.scope = this.localSymbolTable;
        this.localSymbolTable = new SymbolTable();
        this.localSymbolTable.father = iterationStat.scope;

        String scopeBeginName = "iterationScope" + this.iterationId++;
        DescriptionLabel iterationScope = new DescriptionLabel(scopeBeginName);
        Quat quat = new Quat("iterationBegin", iterationScope, null, null);
        quats.add(quat);

        if (iterationStat.init != null) {
            for (ASTExpression init : iterationStat.init)
                this.visit(init);
        }

        String condInL = "iterationCondInLabel" + this.jmpLabelId++;
        DescriptionLabel condInLabel = new DescriptionLabel(condInL, this.quats.size());
        Quat quat1 = new Quat("label", condInLabel, null, null);
        quats.add(quat1);

        if (iterationStat.cond != null) {
            for (ASTExpression cond : iterationStat.cond)
                this.visit(cond);
        }

        String gotoIterationEnd = "iterationGotoEnd" + this.jmpLabelId++;
        DescriptionLabel gotoIterationEndLabel = new DescriptionLabel(gotoIterationEnd);

        Quat quat2 = new Quat("jf", gotoIterationEndLabel, null, null);
        quats.add(quat2);

        this.visit(iterationStat.stat);

        String gotocondCheck = "iterationGotoCond" + this.jmpLabelId++;
        DescriptionLabel gotocondCheckLabel = new DescriptionLabel(gotocondCheck, this.quats.size());

        Quat quat3 = new Quat("label", gotocondCheckLabel, null, null);
        quats.add(quat3);

        if (iterationStat.step != null) {
            for (ASTExpression step : iterationStat.step)
                this.visit(step);
        }

        Quat quat4 = new Quat("jmp", condInLabel, null, null);
        quats.add(quat4);

        Quat quat5 = new Quat("label", gotoIterationEndLabel, null, null);
        quats.add(quat5);

        String scopeEndName = "iterationScopeBegin" + this.iterationId++;
        Quat quat6 = new Quat("iterationEnd", iterationScope, null, null);
        quats.add(quat6);

        // ���ű��л�
        this.localSymbolTable = iterationStat.scope;

    }

    @Override
    public void visit(ASTLabeledStatement labeledStat) throws Exception {
        // TODO Auto-generated method stub
        String label = labeledStat.label.value;
        DescriptionLabel inLabel = new DescriptionLabel(label, this.quats.size());
        Quat quat = new Quat("label", inLabel, null, null);
        quats.add(quat);
        this.labelTable.put(label, inLabel);

        this.visit(labeledStat.stat);

    }

    @Override
    public void visit(ASTMemberAccess memberAccess) throws Exception {
        // TODO Auto-generated method stub

    }

    // a++, a++, a., a->
    // ("=", expr, , temp)
    // ("op", temp, , expr)
    @Override
    public void visit(ASTPostfixExpression postfixExpression) throws Exception {
        // TODO Auto-generated method stub
        String op = postfixExpression.op.value;
        ASTNode temp = new TemporaryValue(++tmpId);

        String name = ((TemporaryValue) temp).name();
        if (this.globalSymbolTable == this.localSymbolTable) {
            this.globalSymbolTable.addVariable(name, "int");
        } else {
            this.localSymbolTable.addVariable(name, "int");
        }

        Quat quat = new Quat("=", temp, postfixExpression.expr, null);
        quats.add(quat);
        Quat quat1 = new Quat(op, postfixExpression, temp, null);
        quats.add(quat1);

        map.put(postfixExpression, temp);

    }

    // ("ret", , , ) ("ret", , , returnValue)
    @Override
    public void visit(ASTReturnStatement returnStat) throws Exception {
        // TODO Auto-generated method stub
        // return ;
        if (returnStat.expr == null) {
            Quat quat = new Quat("ret", null, null, null);
            quats.add(quat);
        } else {
            for (ASTExpression expr : returnStat.expr) {
                this.visit(expr);
            }
            ASTNode ret = map.get(returnStat.expr.get(0));
            Quat quat = new Quat("ret", ret, null, null);
            quats.add(quat);
        }

    }

    // cond -> judge -> jmpFalse -> then -> jmpEnd-> falseLabel -> otherwise -> endLabel
    // ("ifBegin", , , ), ..., ("jf", cond, , falseLabel), ..., ("jmp", , , endLabel),
    // ("label", , , falseLabel), ..., ("label", , , endLabel)
    @Override
    public void visit(ASTSelectionStatement selectionStat) throws Exception {
        // TODO Auto-generated method stub

        for (ASTExpression cond : selectionStat.cond) {
            this.visit(cond);
        }

        ASTNode res = map.get(selectionStat.cond.get(0));
        String label1 = "ifCondFalseLabel" + this.jmpLabelId++;
        DescriptionLabel ifCondFalseLabel = new DescriptionLabel(label1);
        Quat quat = new Quat("jf", res, ifCondFalseLabel, null);
        quats.add(quat);

        this.visit(selectionStat.then);

        String label2 = "gotoEndLabel" + this.jmpLabelId++;
        DescriptionLabel gotoEndLabel = new DescriptionLabel(label2);
        Quat quat1 = new Quat("jmp", gotoEndLabel, null, null);
        quats.add(quat1);

        ifCondFalseLabel.destination = this.quats.size();
        Quat quat2 = new Quat("label", ifCondFalseLabel, null, null);
        quats.add(quat2);

        if (selectionStat.otherwise != null) {
            this.visit(selectionStat.otherwise);
        }

        gotoEndLabel.destination = this.quats.size();
        Quat quat3 = new Quat("label", gotoEndLabel, null, null);
        quats.add(quat3);

    }

    @Override
    public void visit(ASTStringConstant stringConst) throws Exception {
        // TODO Auto-generated method stub
        map.put(stringConst, stringConst);
    }

    @Override
    public void visit(ASTTypename typename) throws Exception {
        // TODO Auto-generated method stub

    }

    // ++a, --a: (op, a, , a)
    // &a, *a, +a, -a, !a, sizeof(a): (op, a, , temp)
    @Override
    public void visit(ASTUnaryExpression unaryExpression) throws Exception {
        // TODO Auto-generated method stub
        String op = unaryExpression.op.value;
        if (op.equals("++") || op.equals("--")) {
            this.visit(unaryExpression.expr);

            // (op, a, , a)
            ASTNode res = map.get(unaryExpression.expr);
            Quat quat = new Quat(op, res, res, null);
            quats.add(quat);
            map.put(unaryExpression, res);
        } else {
            this.visit(unaryExpression.expr);

            ASTNode res = new TemporaryValue(++tmpId);
            String name = ((TemporaryValue) res).name();

            if (this.globalSymbolTable == this.localSymbolTable) {
                this.globalSymbolTable.addVariable(name, "int");
            } else {
                this.localSymbolTable.addVariable(name, "int");
            }

            // (op, a, , temp)
            ASTNode expr = map.get(unaryExpression.expr);
            Quat quat = new Quat(op, res, expr, null);
            quats.add(quat);
            map.put(unaryExpression, res);
        }

    }

    @Override
    public void visit(ASTUnaryTypename unaryTypename) throws Exception {
        // TODO Auto-generated method stub

    }

    // ("func", returnType, argNum, funcName)
    // ("param", type, , argName)
    @Override
    public void visit(ASTFunctionDefine functionDefine) throws Exception {
        ASTToken typeSpecifier = functionDefine.specifiers.get(0);

        functionDefine.scope = this.localSymbolTable;
        this.localSymbolTable = new SymbolTable();

        String funcname = functionDefine.declarator.getName();
        DescriptionLabel funcLabel = new DescriptionLabel(funcname);
        ASTIntegerConstant paramNum = new ASTIntegerConstant(((ASTFunctionDeclarator) functionDefine.declarator).params.size(), -1);
        Quat quat = new Quat("func", typeSpecifier, paramNum, funcLabel);
        quats.add(quat);

        ASTFunctionDeclarator astFunctionDeclarator = (ASTFunctionDeclarator) functionDefine.declarator;
        LinkedList<ASTNode> params = new LinkedList<>();
        for (ASTParamsDeclarator param : astFunctionDeclarator.params) {
            ASTToken paramTypeSpecifier = param.specfiers.get(0);

            String paramName = param.declarator.getName();
            this.localSymbolTable.addVariable(paramName, paramTypeSpecifier.value);
            params.add(param);

            DescriptionLabel paramLabel = new DescriptionLabel(paramName);
            Quat quat1 = new Quat("param", paramLabel, paramTypeSpecifier, null);
            quats.add(quat1);
        }

        this.functionTable.addVariable(funcname, typeSpecifier.value, params);

        this.visit(functionDefine.declarator);
        this.visit(functionDefine.body);

        Quat quat1 = new Quat("funcEnd", functionDefine.declarator, null, null);
        quats.add(quat1);

        this.localSymbolTable = this.globalSymbolTable;
    }

    @Override
    public void visit(ASTDeclarator declarator) throws Exception {
        // TODO Auto-generated method stub
        if (declarator instanceof ASTVariableDeclarator) {
            visit((ASTVariableDeclarator) declarator);
        } else if (declarator instanceof ASTArrayDeclarator) {
            visit((ASTArrayDeclarator) declarator);
        } else if (declarator instanceof ASTFunctionDeclarator) {
            visit((ASTFunctionDeclarator) declarator);
        }
    }

    @Override
    public void visit(ASTStatement statement) throws Exception {
        if (statement instanceof ASTIterationDeclaredStatement) {
            visit((ASTIterationDeclaredStatement) statement);
        } else if (statement instanceof ASTIterationStatement) {
            visit((ASTIterationStatement) statement);
        } else if (statement instanceof ASTCompoundStatement) {
            visit((ASTCompoundStatement) statement);
        } else if (statement instanceof ASTSelectionStatement) {
            visit((ASTSelectionStatement) statement);
        } else if (statement instanceof ASTExpressionStatement) {
            visit((ASTExpressionStatement) statement);
        } else if (statement instanceof ASTBreakStatement) {
            visit((ASTBreakStatement) statement);
        } else if (statement instanceof ASTContinueStatement) {
            visit((ASTContinueStatement) statement);
        } else if (statement instanceof ASTReturnStatement) {
            visit((ASTReturnStatement) statement);
        } else if (statement instanceof ASTGotoStatement) {
            visit((ASTGotoStatement) statement);
        } else if (statement instanceof ASTLabeledStatement) {
            visit((ASTLabeledStatement) statement);
        }
    }

    @Override
    public void visit(ASTToken token) throws Exception {
        // TODO Auto-generated method stub

    }

}
